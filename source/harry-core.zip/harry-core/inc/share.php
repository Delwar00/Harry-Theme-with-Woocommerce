<?php
// harry post social share 
function harry_product_social_share(){ ?>
      <span>Share:</span>
      <a href="https://www.linkedin.com/shareArticle?url=<?php the_permalink(); ?>" target="_blank">
          <i class="fa-brands fa-linkedin-in"></i>
      </a>
      <a href="https://twitter.com/intent/tweet?url=<?php the_permalink(); ?>&text=<?php the_title(); ?>" target="_blank">
          <i class="fab fa-twitter"></i>
      </a>
      <a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank">
          <i class="fab fa-facebook-f"></i>
      </a>
<?php
}

add_action('harry_product_social_share_share','harry_product_social_share');