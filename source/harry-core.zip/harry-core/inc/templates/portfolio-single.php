<?php 
   get_header(); 
   $bg_image_portfolio = function_exists('get_field') ? get_field('background_image') : null;
   $portfolio_gallery = function_exists('get_field') ? get_field('portfolio_gallery') : null;
   $portfolio_gallery = function_exists('get_field') ? get_field('portfolio_gallery') : null;
   $portfolio_url = function_exists('get_field') ? get_field('project_url') : null;
?><!-- breadcrumb area start -->
<section class="breadcrumb__area breadcrumb__style-3 breadcrumb__spacing-2 include-bg pt-200 pb-235 grey-bg-4" data-background="<?php echo esc_html($bg_image_portfolio['url']); ?>">
   <div class="container">
      <div class="row">
         <div class="col-xxl-7">
            <div class="breadcrumb__content p-relative z-index-1">
               <div class="breadcrumb__list">
               <?php if(function_exists('bcn_display'))
                                {
                                    bcn_display();
                                }
                            ?>
               </div>
               </div>
               <h3 class="breadcrumb__title"><?php the_title() ?></h3>
               <p><?php the_excerpt(); ?></p>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- breadcrumb area end -->

         <!-- portfolio area start -->
         <section class="portfolio__area pt-100 pb-120">
            <div class="container">
               <div class="row">
                  <div class="col-xl-8">
                  
                     <div class="portfolio__details-img-list p-relative">
                     <?php if(!empty($portfolio_gallery)) : ?>
                     <div class="portfolio__details-img-list-social d-flex flex-column ">
                              <a href="https://www.linkedin.com/shareArticle?url=<?php the_permalink(); ?>" target="_blank">
                                 <i class="fa-brands fa-linkedin-in"></i>
                              </a>
                              <a href="https://twitter.com/intent/tweet?url=<?php the_permalink(); ?>&text=<?php the_title(); ?>" target="_blank">
                                 <i class="fab fa-twitter"></i>
                              </a>
                              <a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank">
                                 <i class="fab fa-facebook-f"></i>
                              </a>    
                     </div>
                     
                        <?php foreach($portfolio_gallery  as $gallery_item): ?>
                        <div class="portfolio__details-img-list-box mb-10 p-relative">
                           <img src="<?php echo esc_html($gallery_item['url']); ?>" alt="">
                        </div>
                        <?php endforeach; endif;?>
                     </div>
                  </div>
                  <div class="col-xl-4">
                     <div class="portfolio__details-info-wrapper">
                        <div class="portfolio__details-info-content">
                           <h3 class="portfolio__details-info-box-title"><?php echo esc_html__('Project Details','harry'); ?></h3>
                           <p><?php the_content(); ?></p>
                        </div>

                        <?php
                        if( have_rows('project_details') ): ?>
                        <div class="portfolio__details-meta flex-wrap mb-40">
                        <?php while ( have_rows('project_details') ) : the_row(); ?>
                           <div class="portfolio__details-meta-item d-flex align-items-start">
                              <div class="portfolio__details-meta-icon">
                                 <span>
                                    
                                 <?php echo get_sub_field('svg_icon'); ?>                                     
                                 </span>
                              </div>
                              <div class="portfolio__details-meta-content">
                                 <h5><?php the_sub_field('title'); ?></h5>
                                 <span><?php the_sub_field('subtitle'); ?></span>
                              </div>
                           </div>
                        <?php endwhile; ?>
                        </div>
                        <?php endif; ?>
                        <div class="portfolio__details-info-btn">
                           <a href="<?php echo esc_url($portfolio_url); ?>" class="tp-btn w-100"><?php echo esc_html__('Visit Website','harry'); ?></a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!-- portfolio area end -->
         <?php 
            $prev_post = get_previous_post();
            $next_post = get_next_post();
         ?>
         <!-- portfolio navigation area start -->
         <?php if(!empty($prev_post) && (!empty($next_post))) : ?>
         <section class="portfolio__navigation-area portfolio__more-border d-none d-md-block">
            <div class="container">
               <div class="row align-items-center">
                  <div class="col-xl-5 col-lg-5 col-md-5">
                     <div class="portfolio__more-left d-flex align-items-center">
                        <div class="portfolio__more-icon">
                           <a href="portfolio-details-list.html">
                              <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M7 12.9718L2.06061 8.04401C1.47727 7.46205 1.47727 6.50975 2.06061 5.92778L7 1" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                              </svg>
                           </a>
                        </div>
                        <div class="portfolio__more-content">
                           <p><?php echo esc_html__('Previous Work','harry'); ?></p>
                           <h4>
                              <a href="<?php echo get_the_permalink( $prev_post ); ?>"><?php echo get_the_title( $prev_post ); ?></a>
                           </h4>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-2 col-lg-2 col-md-2">
                     <div class="portfolio__more-menu text-center">
                        <a href="<?php echo home_url('/'); ?>">
                           <span>
                              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M11.6673 4.66662C12.9559 4.66662 14.0006 3.62196 14.0006 2.33331C14.0006 1.04466 12.9559 0 11.6673 0C10.3786 0 9.33398 1.04466 9.33398 2.33331C9.33398 3.62196 10.3786 4.66662 11.6673 4.66662Z" fill="currentColor"/>
                                 <path d="M2.33331 4.66662C3.62196 4.66662 4.66662 3.62196 4.66662 2.33331C4.66662 1.04466 3.62196 0 2.33331 0C1.04466 0 0 1.04466 0 2.33331C0 3.62196 1.04466 4.66662 2.33331 4.66662Z" fill="currentColor"/>
                                 <path d="M11.6673 13.9996C12.9559 13.9996 14.0006 12.955 14.0006 11.6663C14.0006 10.3777 12.9559 9.33301 11.6673 9.33301C10.3786 9.33301 9.33398 10.3777 9.33398 11.6663C9.33398 12.955 10.3786 13.9996 11.6673 13.9996Z" fill="currentColor"/>
                                 <path d="M2.33331 13.9996C3.62196 13.9996 4.66662 12.955 4.66662 11.6663C4.66662 10.3777 3.62196 9.33301 2.33331 9.33301C1.04466 9.33301 0 10.3777 0 11.6663C0 12.955 1.04466 13.9996 2.33331 13.9996Z" fill="currentColor"/>
                              </svg>                                    
                           </span>
                        </a>
                     </div>
                  </div>
                  <div class="col-xl-5 col-lg-5 col-md-5">
                     <div class="portfolio__more-right d-flex align-items-center justify-content-end">
                           <div class="portfolio__more-content">
                              <p><?php echo esc_html__('Next Work','harry'); ?></p>
                              <h4>
                                 <a href="<?php echo get_the_permalink( $next_post ); ?>"><?php echo get_the_title( $next_post ); ?></a>
                              </h4>
                           </div>
                           <div class="portfolio__more-icon">
                              <a href="portfolio-details-list.html">
                                 <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 12.9718L5.93939 8.04401C6.52273 7.46205 6.52273 6.50975 5.93939 5.92778L1 1" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                                 </svg>                                                      
                              </a>
                           </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <?php endif; ?>
         <!-- portfolio navigation area end -->


<?php get_footer(); ?>


