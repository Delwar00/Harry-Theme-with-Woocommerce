<?php
namespace HarryCoreModule\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Harry_Icon_Box_Widget extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'harry_icon_box_widget';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Harry Icon Box', 'harry-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-group
		0xe848';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'harry-custom-category' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'harry-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->Harry_Content_Controls();
		$this->Harry_Style_Controls();
	}
	protected function Harry_Content_Controls() {
		$this->start_controls_section(
			'harry_icon_box',
			[
				'label' => esc_html__( 'Harry Hero', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'harry_icon_box_select',
			[
				'label' => esc_html__( 'Icon Box Style', 'harry' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style-01',
				'options' => [
					'style-01' => esc_html__( 'Style 01', 'harry' ),
					'style-02'  => esc_html__( 'Style 02', 'harry' ),
				],
			]
		);
		$this->add_control(
			'harry_project',
			[
				'label' => esc_html__( 'Harry Project Count', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is Sub heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your Sub title here', 'harry' ),
				'label_block' => true,
				'condition' => [
					'harry_icon_box_select' => 'style-01',
				],
			]
		);
		$this->add_control(
			'harry_title',
			[
				'label' => esc_html__( 'Harry Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your title here', 'harry' ),
				'label_block' => true
			]
		);
		
		$this->add_control(
			'harry_description',
			[
				'label' => esc_html__( 'Harry Description', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'This is heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your title here', 'harry' ),
				'label_block' => true,
				'condition' => [
					'harry_icon_box_select' => 'style-02',
				],
			]
		);
		$this->add_control(
			'icon_select',
			[
				'label' => esc_html__( 'Choose Icon', 'harry' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'icon',
				'options' => [
					'icon' => esc_html__( 'Icon', 'harry' ),
					'svg'  => esc_html__( 'SVG', 'harry' ),
				],
				'selectors' => [
					'{{WRAPPER}} .your-class' => 'icon_select: {{VALUE}};',
				],
				'label_block' => true
			]
		);
		$this->add_control(
			'harry_social_icon',
			[
				'label' => esc_html__( 'Social', 'harry' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-smile',
					'library' => 'fa-solid',
				],
				'recommended' => [
					'fa-solid' => [
						'circle',
						'dot-circle',
						'square-full',
					],
					'fa-regular' => [
						'circle',
						'dot-circle',
						'square-full',
					],
				],
				'condition' => [
					'icon_select' => 'icon',
				],
			]
		);
		$this->add_control(
			'harry_svg',
			[
				'label' => esc_html__( 'SVG', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'SVG Icon Here', 'harry' ),
				'condition' => [
					'icon_select' => 'svg',
				],
			]
		);
		$this->add_control(
			'harry_button_text',
			[
				'label' => esc_html__( 'Button Text', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Explore Section', 'harry' ),
				'placeholder' => esc_html__( 'Type your Button Text Here', 'harry' ),
				'condition' => [
					'harry_icon_box_select' => 'style-02',
				],
			]
		);
		
		$this->add_control(
			'icon_url',
			[
				'label' => esc_html__( 'Url', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '#' , 'harry' ),
				'label_block' => true,
			]
		);
		
		$this->end_controls_section();
	
	}
	protected function Harry_Style_Controls() {
		$this->start_controls_section(
			'icon_box_style_section',
			[
				'label' => esc_html__( 'Style', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				// 'condition' => [
				// 	'harry_icon_box_select' => 'style-02',
				// ],
			]
		);

		
		$this->add_responsive_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'harry' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .harry-elementor-title' => 'color: {{VALUE}}',
				],
			]
		  );
		  $this->add_responsive_control(
			'bg_color',
			[
				'label' => esc_html__( 'Bg Color', 'harry' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .harry-elementor-title' => 'background-color: {{VALUE}}',
				],
			]
		  );
		$this->add_responsive_control(
			'title_padding',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Padding', 'harry' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .harry-elementor-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'title_margin',
			[
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Margin', 'harry' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .harry-elementor-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'title_border_radius',
			[
			    'label' => esc_html__( 'Border Radius', 'harry' ),
			    'type' => \Elementor\Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%' ],
			    'selectors' => [
				  '{{WRAPPER}} .harry-elementor-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
			]
		  );
		  $this->add_responsive_control(
			'title_width',
			[
			    'label' => esc_html__( 'Width', 'harry' ),
			    'type' => \Elementor\Controls_Manager::SLIDER,
			    'size_units' => [ 'px', '%', 'em', 'rem' ],
			    'range' => [
				  'px' => [
					'min' => 0,
					'max' => 1200,
				  ],
				  '%' => [
					'min' => 0,
					'max' => 100,
				  ],
				  'em' => [
					'min' => 0,
					'max' => 100,
				  ],
				  'rem' => [
					'min' => 0,
					'max' => 100,
				  ],
			    ],
			    'selectors' => [
				  '{{WRAPPER}} .harry-elementor-title' => 'width: {{SIZE}}{{UNIT}};',
			    ],
			]
		  );
		  $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'harry_title',
				'selector' => '{{WRAPPER}} .harry-elementor-title',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'selector' => '{{WRAPPER}} .harry-elementor-title',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'title_border',
				'selector' => '{{WRAPPER}} .harry-elementor-title',
			]
		);
		
		$this->end_controls_section();

	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		
		
		?>
		 <?php if($settings['harry_icon_box_select'] == 'style-01') : ?>
                     <div class="services__item-9 mb-30 transition-3">
                        <div class="services__item-9-top d-flex align-items-start justify-content-between">
                           <div class="services__icon-9">
                              <span>
				
						
					<?php if(!empty($settings['icon_select'] == 'icon' )) : ?>
					    <?php \Elementor\Icons_Manager::render_icon( $settings['harry_social_icon'], [ 'aria-hidden' => 'true' ] ); ?>
					<?php else: ?>
						<?php echo $settings['harry_svg']; ?>
					<?php endif; ?>
                                  
                                 <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services/9/services-icon-shape.png" alt="">                               
                              </span>
                           </div>
                           <div class="services__btn-9">
                              <a href="<?php echo esc_url($settings['icon_url']); ?>"><i class="fa-light fa-arrow-up-right"></i></a>
                           </div>
                        </div>
                        <div class="services__content-9">
				<?php if(!empty($settings['harry_project'])) : ?>
                           <span class="services-project"><?php echo esc_html($settings['harry_project']); ?></span>
				<?php endif; ?>
                           <h3 class="services__title-9 harry-elementor-title">
				<?php if(!empty($settings['harry_title'])) : ?>
                           <a href="<?php echo esc_url($settings['icon_url']); ?>"><?php echo esc_html($settings['harry_title']); ?></a>
				<?php endif; ?>
                           </h3>
                        </div>
                     </div>
		<?php elseif($settings['harry_icon_box_select'] == 'style-02') : ?>

			<div class="services__item transition-3 mb-30 fix wow fadeInUp" data-wow-delay=".3s" data-wow-duration="1s">
                        <div class="services__shape">
                           <img class="services__shape-1" src="<?php echo get_template_directory_uri(); ?>/assets/img/services/shape/services-shape-1.png" alt="">
                           <img class="services__shape-2" src="<?php echo get_template_directory_uri(); ?>/assets/img/services/shape/services-shape-2.png" alt="">
                        </div>
                        <div class="services__item-inner">
                           <div class="services__icon">
                              <span>
					<?php if(!empty($settings['icon_select'] == 'icon' )) : ?>
					    <?php \Elementor\Icons_Manager::render_icon( $settings['harry_social_icon'], [ 'aria-hidden' => 'true' ] ); ?>
					<?php else: ?>
						<?php echo $settings['harry_svg']; ?>
					<?php endif; ?>
                              </span>
                           </div>
                           <div class="services__content">
				      <?php if(!empty($settings['harry_title'])) : ?>
						<h3 class="services__title harry-elementor-title">
							<a href="<?php echo esc_url($settings['icon_url']); ?>" ><?php echo esc_html($settings['harry_title']); ?></a>
						</h3>
					<?php endif; ?>
					<?php if(!empty($settings['harry_description'])) : ?>
                              	<p><?php echo esc_html($settings['harry_description']); ?></p>
					<?php endif; ?>
                              <div class="services__btn">
                                 <a href="<?php echo esc_url($settings['icon_url']); ?>" class="tp-btn-border"><?php echo esc_html($settings['harry_button_text']); ?><i class="fa-regular fa-angle-right"></i></a>
                              </div>
                           </div>
                        </div>
                     </div>

		<?php else: ?>
			<h2>There is coming soon</h2>
		<?php endif; ?>

		<?php		
	}

	
}
$widgets_manager->register( new Harry_Icon_Box_Widget() );