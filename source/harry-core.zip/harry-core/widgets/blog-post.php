<?php
namespace HarryCoreModule\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Harry_Blog_Post extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'harry_blog_post';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Harry Blog Post', 'harry-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-handle';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'harry-custom-category' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'harry-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'harry_title_section',
			[
				'label' => esc_html__( 'Harry About', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'harry_post_per_page',
			[
				'label' => esc_html__( 'Post Per Page', 'harry' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 3,
			]
		);
		$this->add_control(
			'cat_list',
			[
				'label' => esc_html__( 'Categories', 'harry' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple' => true,
				'options' => post_cat(),
				'default' => [ 'category', 'description' ],
			]
		);
		$this->add_control(
			'cat_exclude',
			[
				'label' => esc_html__( 'Categories Exclude', 'harry' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple' => true,
				'options' => post_cat(),
				'default' => [ 'category', 'description' ],
			]
		);
		$this->add_control(
			'post_exclude',
			[
				'label' => esc_html__( 'Posts Exclude', 'harry' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple' => true,
				'options' => get_all_post(),
				'default' => [ 'posts', 'description' ],
			]
		);
		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Post order', 'harry' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'asc',
				'options' => [
					'asc' => esc_html__( 'ASC', 'harry' ),
					'desc' => esc_html__( 'DESE', 'harry' ),
				],
			]
		);
		$this->add_control(
			'order_by',
			[
				'label' => esc_html__( 'Order By', 'harry' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'name',
				'options' => [
					'id' => esc_html__( 'ID', 'harry' ),
					'author' => esc_html__( 'Author', 'harry' ),
					'title' => esc_html__( 'Title', 'harry' ),
					'name' => esc_html__( 'Name', 'harry' ),
					'date' => esc_html__( 'Date', 'harry' ),
					'rand' => esc_html__( 'Rand', 'harry' ),
				],
			]
		);
		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$posts_per_page_count = !empty($settings['harry_post_per_page']) ? $settings['harry_post_per_page'] : -1 ;
		$cate_select =  $settings['cat_list'];
		$cat_exclude =  $settings['cat_exclude'];
		$post_exclude =  $settings['post_exclude'];
		$order =  $settings['order'];
		$order_by =  $settings['order_by'];
		$args = array(
			'post_type' => 'post',
			'posts_per_page' => $posts_per_page_count,
			'order' => $order,
			'orderby' => $order_by,
			'post__not_in' => $post_exclude,
			
		);
		
		if(!empty($cate_select || $cat_exclude )){
			$args['tax_query'] = array(
				array(
				'taxonomy' => 'category',
				'field' => 'slug',
				'terms' => !empty($cat_exclude) ? $cat_exclude : $cate_select ,
				'operator' => !empty($cat_exclude) ? 'NOT IN' : 'IN',
				),
			);
		}

		$query = new \WP_Query( $args );
		?>
		<section class="blog__area grey-bg-12 pt-115 pb-90 p-relative z-index-1">
        <div class="container">
          
          <div class="row">
	    <?php if ( $query -> have_posts() ) :  ?>
		<?php while ( $query -> have_posts() ) :  $query->the_post();
		$categories = get_the_category(get_the_ID());
		// echo "<pre>";
		// var_dump($categories);
		// echo "</pre>";
		?>
            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6">
              <div
                class="blog__item-9 mb-30 wow fadeInUp"
                data-wow-delay=".3s"
                data-wow-duration="1s"
              >
                <div class="blog__thumb-9 w-img fix">
                  <a href="blog-details.html">
                    <?php the_post_thumbnail(); ?>
                  </a>
                </div>
                <div class="blog__content-9">
                  <div class="blog__meta-9">
                    <span>
                      <a href="#"><?php echo get_the_date(); ?></a>
                    </span>
                    <span>
                      <a href="<?php echo esc_url(home_url('/').'category/'.$categories[0]->slug); ?>"><?php echo esc_html($categories[0]->name); ?></a>
                    </span>
                  </div>
                  <h3 class="blog__title-9">
                    <a href="<?php the_permalink(); ?>"
                      ><?php the_title(); ?></a
                    >
                  </h3>
                </div>
              </div>
            </div>
            <?php endwhile; wp_reset_postdata(); endif;?>
          </div>
        </div>
      </section>	




		<?php		
	}

	
}
$widgets_manager->register( new Harry_Blog_Post() );