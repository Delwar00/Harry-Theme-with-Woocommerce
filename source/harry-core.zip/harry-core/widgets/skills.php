<?php
namespace HarryCoreModule\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Harry_Skills extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'harry_skills_widget';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Harry Skills Widget', 'harry-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-external-link-square';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'harry-custom-category' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'harry-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'harry_skills_section',
			[
				'label' => esc_html__( 'Harry Skills', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
	
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'harry_skill_num_count',
			[
				'label' => esc_html__( 'Harry Counter', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Counter', 'harry' ),
				'placeholder' => esc_html__( 'Counter', 'harry' ),
				'label_block' => true
			]
		);
		$repeater->add_control(
			'harry_skill_title',
			[
				'label' => esc_html__( 'Harry Skill Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your title here', 'harry' ),
				'label_block' => true
			]
		);
		$repeater->add_control(
			'harry_skill_image',
			[
				'label' => esc_html__( 'Harry Skill Image', 'harry' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$this->add_control(
			'harry_skill_list',
			[
				'label' => esc_html__( 'Skills List', 'harry' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'harry_skill_title' => esc_html__( 'Title #1', 'harry' ),
					],
					[
						'harry_skill_title' => esc_html__( 'Title #2', 'harry' ),
					],
				],
				'title_field' => '{{{ harry_skill_title }}}',
			]
		);
		
		
		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		
		?>
                     <div class="skill__wrapper-9">
                        <div class="skill__item-wrapper-9">
                           <div class="row">
				   <?php foreach (  $settings['harry_skill_list'] as $key => $item ) : ?>
                              <div class="col-xxl-6 col-md-6 col-sm-6 col-6">
                                 <div class="skill__item-9">
                                    <div class="skill__icon-9">
                                       <span>
                                          <img src="<?php echo $item['harry_skill_image']['url']; ?>);" alt="">
                                       </span>
                                    </div>
                                    <div class="skill__content-9">
                                       <h4><?php echo esc_html($item['harry_skill_title']); ?> <span>(<span data-purecounter-duration="1" data-purecounter-end="90"  class="purecounter"><?php echo esc_html($item['harry_skill_num_count']); ?></span>%)</span></h4>
                                    </div>
                                 </div>
                              </div>
					<?php endforeach; ?>
                           </div>
                        </div>
                     </div>
		<?php		
	}

	
}
$widgets_manager->register( new Harry_Skills() );