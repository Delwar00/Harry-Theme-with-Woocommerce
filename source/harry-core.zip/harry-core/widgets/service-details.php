<?php
namespace HarryCoreModule\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Harry_Service_Details extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'harry_service_details';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Service Details', 'harry-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-handle';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'harry-custom-category' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'harry-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'harry_service_details_page',
			[
				'label' => esc_html__( 'Service Details', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'harry_sub_title',
			[
				'label' => esc_html__( 'Harry Sub Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is Sub heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your Sub title here', 'harry' ),
			]
		);
		$this->add_control(
			'harry_title',
			[
				'label' => esc_html__( 'Harry Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your title here', 'harry' ),
			]
		);
		$this->add_control(
			'harry_details',
			[
				'label' => esc_html__( 'Harry Details', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'This is Harry details', 'harry' ),
				'placeholder' => esc_html__( 'Type your details here', 'harry' ),
			]
		);
		$this->add_control(
			'harry_button_text',
			[
				'label' => esc_html__( 'Button Text', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Our Services', 'harry' ),
				'placeholder' => esc_html__( 'Type your Button Text Here', 'harry' ),
			]
		);
		
		$this->add_control(
			'harry_button_url',
			[
				'label' => esc_html__( 'Button Url', 'harry' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true
				],
				'label_block' => true,
			]
		);
		$this->add_control(
			'harry_service_image1',
			[
				'label' => esc_html__( 'Harry service Image01', 'harry' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				
				
			]
		);
		$this->add_control(
			'harry_service_image2',
			[
				'label' => esc_html__( 'Harry service Image02', 'harry' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				
				
			]
		);
		$this->end_controls_section();

		
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		if ( ! empty( $settings['harry_button_url']['url'] ) ) {
			$this->add_link_attributes( 'harry_button_url_receive', $settings['harry_button_url'] );
			$this->add_render_attribute( 'harry_button_url_receive', 'class', 'tp-btn' );
			}
		
		?>
		 
		 <section class="about__area pb-140">
            <div class="container">
               <div class="row">
                  <div class="col-xl-6 col-lg-6">
                     <div class="about__thumb-wrapper-14 p-relative wow fadeInUp" data-wow-delay=".3s" data-wow-duration="1s">
                        <div class="about__shape">
                           <img class="about__shape-8" src="<?php echo get_template_directory_uri(); ?>/assets/img/about/14/about-shape-1.png" alt="">
                           <img class="about__shape-9" src="<?php echo get_template_directory_uri(); ?>/assets/img/about/14/about-shape-2.png" alt="">
                        </div>
                        <div class="about__thumb-14 m-img">
				   <?php if(!empty($settings['harry_service_image1']['url'])) : ?>
                           	<img class="about-img-1" src="<?php echo esc_html($settings['harry_service_image1']['url']); ?>" alt="">
				   <?php endif; ?>
				   <?php if(!empty($settings['harry_service_image2']['url'])) : ?>
                           	<img class="about-img-2" src="<?php echo esc_html($settings['harry_service_image2']['url']); ?>" alt="">
				   <?php endif; ?>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-6 col-lg-6">
                     <div class="about__wrapper-14 pl-75 pt-45 wow fadeInUp" data-wow-delay=".5s" data-wow-duration="1s">
                        <div class="tp-section-wrapper-2 mb-40">
				   <?php if(!empty($settings['harry_sub_title'])) : ?>
				  	 <span class="tp-section-subtitle-2"><?php echo esc_html($settings['harry_sub_title']); ?></span>
				   <?php endif; ?>
				   <?php if(!empty($settings['harry_title'])) : ?>
                           	<h3 class="tp-section-title-2"><?php echo esc_html($settings['harry_title']); ?></h3>
				   <?php endif; ?>
				   <?php if(!empty($settings['harry_details'])) : ?>
                          	 <p><?php echo esc_html($settings['harry_details']); ?></p>
				   <?php endif; ?>
				</div>

                        <div class="about-btn">
                           <a <?php echo $this->get_render_attribute_string( 'harry_button_url_receive' ); ?>><?php echo esc_html($settings['harry_button_text']); ?></a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
		<?php		
	}

	
}
$widgets_manager->register( new Harry_Service_Details() );