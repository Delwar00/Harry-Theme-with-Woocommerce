<?php
namespace HarryCoreModule\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Harry_Awards extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'harry_awards_widget';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Awards Widget', 'harry-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-external-link-square';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'harry-custom-category' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'harry-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'harry_awards_section',
			[
				'label' => esc_html__( 'Harry Awards', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
	
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'harry_awards_sub_title',
			[
				'label' => esc_html__( 'Harry Awards Sub Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your title here', 'harry' ),
				'label_block' => true
			]
		);
		$repeater->add_control(
			'harry_awards_title',
			[
				'label' => esc_html__( 'Harry Awards Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your title here', 'harry' ),
				'label_block' => true
			]
		);
		$repeater->add_control(
			'harry_awards_image',
			[
				'label' => esc_html__( 'Harry Awards Image', 'harry' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$repeater->add_control(
			'harry-button-url',
			[
				'label' => esc_html__( 'Awards Url', 'harry' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true
				],
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'harry_awards_date',
			[
				'label' => esc_html__( 'Harry Awards Date', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your title here', 'harry' ),
				'label_block' => true
			]
		);
		$this->add_control(
			'harry_awards_list',
			[
				'label' => esc_html__( 'Awards List', 'harry' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'harry_awards_title' => esc_html__( 'Title #1', 'harry' ),
					],
					[
						'harry_awards_title' => esc_html__( 'Title #2', 'harry' ),
					],
				],
				'title_field' => '{{{ harry_awards_title }}}',
			]
		);
		
		
		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		if ( ! empty( $settings['harry-button-url']['url'] ) ) {
			$this->add_link_attributes( 'harry-button-url-receive', $settings['harry-button-url'] );
			}
		
		?>



			<div class="award__item-wrapper-9">
				<?php foreach (  $settings['harry_awards_list'] as $item ) : ?>
					<div class="award__item-9 p-relative wow fadeInUp" data-wow-delay=".3s" data-wow-duration="1s">
					<div class="row align-items-center">
						<div class="col-xl-3 col-lg-3 col-md-3">
						<div class="award__topic">
							<p><?php echo esc_html($item['harry_awards_date']); ?></p>
						</div>
						</div>
						<div class="col-xl-7 col-lg-7 col-md-7">
						<div class="award__content-9">
							<h3 class="award__title-9">
							<a href="portfolio-details.html" class="tp-img-reveal tp-img-reveal-item" data-img="<?php echo $item['harry_awards_image']['url']; ?>" data-fx="1"><?php echo esc_html($item['harry_awards_title']); ?></a>
							</h3>
							<p><?php echo esc_html($item['harry_awards_sub_title']); ?></p>
						</div>
						</div>
						
						<div class="col-xl-2 col-lg-2 col-md-2">
						<div class="award__btn-9 text-md-end">
							<a href="<?php echo esc_html($item['harry-button-url']); ?>" class="career-link-btn">
							<svg width="22" height="18" viewBox="0 0 22 18" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path d="M12.7334 1L21 9.00007L12.7334 17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M0.999999 8.99756H21" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>                                          
							</a>
						</div>
						</div>
					</div>
					</div>
				<?php endforeach; ?> 
                  </div>

		<?php		
	}

	

}
$widgets_manager->register( new Harry_Awards() );