<?php
namespace HarryCoreModule\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Harry_Project extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'harry_project_widget';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Project Widget', 'harry-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-external-link-square';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'harry-custom-category' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'harry-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'harry_project_style',
			[
				'label' => esc_html__( 'Project Style', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'harry_project_select',
			[
				'label' => esc_html__( 'Project Style', 'harry' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style-01',
				'options' => [
					'style-01' => esc_html__( 'Style 01', 'harry' ),
					'style-02'  => esc_html__( 'Style 02', 'harry' ),
					'style-03' => esc_html__( 'Style 03', 'harry' ),
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'harry_project_section',
			[
				'label' => esc_html__( 'Harry Project', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
	
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'harry_project_repeater_select',
			[
				'label' => esc_html__( 'Choose Style', 'harry' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style-01',
				'options' => [
					'style-01' => esc_html__( 'Style 01 (image)', 'harry' ),
					'style-02'  => esc_html__( 'Style 02 (video)', 'harry' ),
				],
			]
		);
		$repeater->add_control(
			'harry_project_sub_title',
			[
				'label' => esc_html__( 'Harry Sub Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your title here', 'harry' ),
				'label_block' => true
			]
		);
		$repeater->add_control(
			'harry_project_title',
			[
				'label' => esc_html__( 'Harry Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your title here', 'harry' ),
				'label_block' => true
			]
		);
		
		$repeater->add_control(
			'harry_project_format_select',
			[
				'label' => esc_html__( 'Project Format', 'harry' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'image',
				'options' => [
					'image' => esc_html__( 'Image', 'harry' ),
					'video'  => esc_html__( 'Video', 'harry' ),
				],
				'condition' => [
					'harry_project_repeater_select' => 'style-02',
				],
			]
		);
		$repeater->add_control(
			'harry_project_image',
			[
				'label' => esc_html__( 'Harry Process Image', 'harry' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				
				
			]
		);
		$repeater->add_control(
			'harry_project_video',
			[
				'label' => esc_html__( 'Video Url', 'harry' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true
				],
				'label_block' => true,
				'condition' => [
					'harry_project_format_select' => 'video',
				],
				
			]
		);
		$repeater->add_control(
			'harry_project_url',
			[
				'label' => esc_html__( 'Project Url', 'harry' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true
				],
				'label_block' => true,
			]
		);
		$this->add_control(
			'harry_project_list',
			[
				'label' => esc_html__( 'Project List', 'harry' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'harry_project_title' => esc_html__( 'Title #1', 'harry' ),
					],
					[
						'harry_project_title' => esc_html__( 'Title #2', 'harry' ),
					],
				],
				'title_field' => '{{{ harry_project_title }}}',
			]
		);
		
		
		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		
		
		<?php if($settings['harry_project_select'] == 'style-01') : ?>
		<section class="portfolio__area portfolio__overlay-9 fix">
				<div class="container-fluid gx-0">
				<div class="row gx-0">
					<div class="col-xxl-12">
					<div class="portfolio__slider-9 has-scrollbar p-relative">
						<div class="portfolio__slider-active-9 swiper-container">
						<div class="swiper-wrapper">

						<?php foreach (  $settings['harry_project_list'] as $key => $item ) : ?>
							<div class="portfolio__item-9 w-img swiper-slide wow fadeInUp" data-wow-delay=".3s" data-wow-duration="1s">
							<div class="portfolio__thumb-9" style="background-image: url(<?php echo $item['harry_project_image']['url']; ?>);" data-background="<?php echo $item['harry_project_image']['url']; ?>"></div>
							<div class="portfolio__content-9">
								<div class="portfolio__tag-9">
								<span>
									<a href="#"><?php echo esc_html($item['harry_project_title']); ?></a>
								</span>
								</div>
								<h3 class="portfolio__title-9">
								<a href="portfolio-details.html"><?php echo esc_html($item['harry_project_sub_title']); ?></a>
								</h3>
							</div>
							</div>

						<?php endforeach; ?>
						</div>
						</div>
						<div class="portfolio__nav-9 d-none d-sm-block">
						<button type="button" class="portfolio-button-prev-9"><i class="fa-regular fa-chevron-left"></i></button>
						<button type="button" class="portfolio-button-next-9"><i class="fa-regular fa-chevron-right"></i></button>
						</div>
						<div class="tp-scrollbar mt-70 mb-50 grey-bg-12"></div>
					</div>
					</div>
				</div>
			</div>
		</section>
		<?php elseif($settings['harry_project_select'] == 'style-02') : ?>
		
		<section class="portfolio__area pt-110 pb-70">
            <div class="container">
               <div class="row tp-gx-4">
		   <?php foreach (  $settings['harry_project_list'] as $key => $item ) :  ?>
			<?php if($item['harry_project_format_select'] == 'image') : ?>
                  <div class="col-xl-4 col-lg-4 col-md-6">
                     <div class="portfolio__grid-item mb-40 wow fadeInUp" data-wow-delay=".3s" data-wow-duration="1s">
                        <div class="portfolio__grid-thumb w-img fix">
                           <a href="portfolio-details-list.html">
                              <img src="<?php echo $item['harry_project_image']['url']; ?>" alt="">
                           </a>
                           <div class="portfolio__grid-popup">
                              <a href="<?php echo $item['harry_project_image']['url']; ?>" class="popup-image" data-effect="mfp-zoom-in">
                                 <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M14.1667 8.33341H0.833333C0.377778 8.33341 0 7.95564 0 7.50008C0 7.04453 0.377778 6.66675 0.833333 6.66675H14.1667C14.6222 6.66675 15 7.04453 15 7.50008C15 7.95564 14.6222 8.33341 14.1667 8.33341Z" fill="currentColor"/>
                                    <path d="M7.4974 15C7.04184 15 6.66406 14.6222 6.66406 14.1667V0.833333C6.66406 0.377778 7.04184 0 7.4974 0C7.95295 0 8.33073 0.377778 8.33073 0.833333V14.1667C8.33073 14.6222 7.95295 15 7.4974 15Z" fill="currentColor"/>
                                 </svg>                                    
                              </a>
                           </div>
                        </div>
                        <div class="portfolio__grid-content">
                           <h3 class="portfolio__grid-title">
                              <a href="portfolio-details-list.html"><?php echo esc_html($item['harry_project_title']); ?></a>
                           </h3>
                           <div class="portfolio__grid-bottom">
                              <div class="portfolio__grid-category">
                                 <span>
                                    <a href="#"><?php echo esc_html($item['harry_project_sub_title']); ?></a>
                                 </span>
                              </div>
                              <div class="portfolio__grid-show-project">
                                 <a href="<?php echo $item['harry_project_url']['url']; ?>" class="portfolio-link-btn">
					   <?php echo esc_html__('Show project','harry'); ?> 
                                    <span>
                                       <svg width="26" height="9" viewBox="0 0 26 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M21.6934 1L25 4.20003L21.6934 7.4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                          <path d="M0.999999 4.19897H25" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                       </svg>
                                    </span>
                                 </a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
			<?php else : ?>
			<div class="col-xl-4 col-lg-4 col-md-6">
                     <div class="portfolio__grid-item mb-40 wow fadeInUp" data-wow-delay="1.3s" data-wow-duration="1s">
                        <div class="portfolio__grid-thumb w-img fix">
                           <a href="portfolio-details-list.html">
                              <img src="<?php echo $item['harry_project_image']['url']; ?>" alt="">
                           </a>
                           <div class="portfolio__grid-video">
                              <a href="<?php echo $item['harry_project_video']['url']; ?>" class="portfolio-play-btn popup-video">
                                 <svg width="18" height="22" viewBox="0 0 18 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M18 11L0 21.3923V0.607696L18 11Z" fill="currentColor"/>
                                 </svg>                                    
                              </a>
                           </div>
                        </div>
                        <div class="portfolio__grid-content">
                           <h3 class="portfolio__grid-title">
                              <a href="portfolio-details-list.html"><?php echo esc_html($item['harry_project_title']); ?></a>
                           </h3>
                           <div class="portfolio__grid-bottom">
                              <div class="portfolio__grid-category">
                                 <span>
                                    <a href="#"><?php echo esc_html($item['harry_project_sub_title']); ?></a>
                                 </span>
                              </div>
                              <div class="portfolio__grid-show-project">
                                 <a href="<?php echo $item['harry_project_url']['url']; ?>" class="portfolio-link-btn">
                                    <?php echo esc_html__('Show project','harry'); ?> 
                                    <span>
                                       <svg width="26" height="9" viewBox="0 0 26 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M21.6934 1L25 4.20003L21.6934 7.4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                          <path d="M0.999999 4.19897H25" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                       </svg>
                                    </span>
                                 </a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
			<?php endif; ?>
		  <?php endforeach; ?>
               </div>
            </div>
         </section>

		<?php else : ?>
		<h2>hello33</h2>
		<?php endif; ?>
		<?php		
	}

	
}
$widgets_manager->register( new Harry_Project() );